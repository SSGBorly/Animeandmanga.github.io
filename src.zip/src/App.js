import Navbar from './Components/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Anime from './Components/Anime';
import Manga from './Components/Manga';
import Sidebar from './Components/Sidebar';
import { useEffect, useState } from 'react';
import Home from './Components/Home';
import SearchItem from './Components/SearchItem';
import Contact from './Components/Contact';


function App() {

  const [search, setSearch] = useState([])
  const [animelist, setAnimelist] = useState([])
  const [topAnime, setTopAnime] = useState([])
  const [topManga, setTopManga] = useState([])

  useEffect(() => {
    fetch('https://api.jikan.moe/v4/top/anime')
      .then(res => res.json())
      .then(json => {
        setTopAnime(json.data)

      })
  }, [])



  useEffect(() => {
    fetch('https://api.jikan.moe/v4/top/manga')
      .then(res => res.json())
      .then(json => {
        setTopManga(json.data)
      })
  }, [])

  console.log(topManga)


  const handleSearch = (e) => {
    e.preventDefault();

    FetchAnime(search)
  }

  const FetchAnime = async (query) => {
    const temp = await fetch(`https://api.jikan.moe/v4/anime?q=${query}&order_by=title&sort=asc&limit=10`)
      .then(res => res.json())
      .then(json => {
        setAnimelist(json.data)
      })
  }



  return (
    <>
      <Router>
        <Navbar handleSearch={handleSearch} search={search} setSearch={setSearch} />
        <Sidebar />
        <SearchItem animelist={animelist} />
        <Routes>
          <Route path='/home' element={<Home animelist={animelist} />}></Route>
          {/* <Route path='/anime' element={<Anime topAnime={topAnime} />}></Route>
          <Route path='/manga' element={<Manga topManga={topManga} />}></Route> */}
          <Route path='/contact' element={<Contact />}></Route>
          {/* <Route path='/registration' element={<Registration />}></Route> */}
        </Routes>
      </Router >
    </>


  );
}

export default App;
