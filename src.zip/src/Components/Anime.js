import React from 'react'
import { Link } from 'react-router-dom'
import AnimeDate from '../AnimeData';

const Anime = ({ topAnime }) => {

    return (
        <>
            <div className="container-fliud Context">
                <h3>Top Anime</h3>
                <div className="row">
                    {
                        topAnime.map((cval) => {
                            return (
                                <>
                                    <div className="col-md-12">
                                        <div className="content" >
                                            <Link key={cval.mal_id} to={cval.link}><img src={cval.images.jpg.image_url} className="card-img-top cdimg" alt="..."></img></Link>
                                            <div className="card-body">
                                                <h5 className="card-title">{cval.title}</h5>
                                                <p>Rank:{cval.rank}<br />
                                                    Rating: {cval.rating}<br />
                                                    Score: {cval.score}<br />
                                                    Season: {cval.season}<br />
                                                    Source: {cval.source}<br />
                                                    Status: {cval.status}</p>
                                            </div>
                                        </div>
                                    </div >
                                </>
                            )
                        })
                    }
                </div>
            </div >
        </>
    )
}

export default Anime
