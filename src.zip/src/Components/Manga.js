import React from 'react'
import MangaData from '../Mangadata'
import { Link } from 'react-router-dom'

const Manga = ({ topManga }) => {

    return (
        <>
            <div className="container-fluid Context">
                <h3>Top Manga</h3>
                <div className="row">
                    {
                        topManga.map((mval) => {
                            return (
                                <>
                                    <div className="col-md-10">
                                        <div className='content'>
                                            <Link to={mval.url}><img src={mval.images.jpg.image_url} className="card-img-top cdimg" alt="..."></img></Link>
                                            <h5 className="card-title">{mval.title}</h5>
                                            <p>Rank: {mval.rank}<br />
                                                Popularity: {mval.popularity}<br />
                                                Score: {mval.score}<br />
                                                Chapters: {mval.chapters}<br />
                                                Volumes: {mval.volumes}<br />
                                                Status: {mval.status}</p>
                                        </div>
                                    </div >
                                </>
                            )
                        })
                    }
                </div>
            </div >

        </>

    )
}

export default Manga
