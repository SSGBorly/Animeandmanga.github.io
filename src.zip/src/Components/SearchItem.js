import React from 'react'
import { Link } from 'react-router-dom'


const SearchItem = ({ animelist }) => {
    return (
        <>
            <div className="row">
                {
                    animelist.map((cval) => {
                        return (
                            <>
                                <div className="col-md-3">
                                    <div className='Sitem'>
                                        <Link to={cval.url}><img src={cval.images.jpg.image_url} className="card-img-top cdimg" alt="..."></img></Link>
                                        <h5 className="card-title">{cval.title}</h5>
                                    </div>
                                </div >
                            </>
                        )
                    })
                }
            </div>
        </>
    )
}

export default SearchItem
